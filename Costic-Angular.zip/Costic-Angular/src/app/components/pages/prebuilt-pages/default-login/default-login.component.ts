import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-default-login',
  templateUrl: './default-login.component.html',
  styleUrls: ['./default-login.component.css']
})
export class DefaultLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
