import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-web-analytics',
  templateUrl: './web-analytics.component.html',
  styleUrls: ['./web-analytics.component.css']
})
export class WebAnalyticsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
