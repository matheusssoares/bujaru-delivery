import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-default-register',
  templateUrl: './default-register.component.html',
  styleUrls: ['./default-register.component.css']
})
export class DefaultRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
