import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sweet-alerts',
  templateUrl: './sweet-alerts.component.html',
  styleUrls: ['./sweet-alerts.component.css']
})
export class SweetAlertsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
