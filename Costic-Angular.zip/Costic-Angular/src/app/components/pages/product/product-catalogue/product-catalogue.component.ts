import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-catalogue',
  templateUrl: './product-catalogue.component.html',
  styleUrls: ['./product-catalogue.component.css']
})
export class ProductCatalogueComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
