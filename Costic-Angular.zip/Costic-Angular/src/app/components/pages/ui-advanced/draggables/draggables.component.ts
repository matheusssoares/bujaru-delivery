import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-draggables',
  templateUrl: './draggables.component.html',
  styleUrls: ['./draggables.component.css']
})
export class DraggablesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
