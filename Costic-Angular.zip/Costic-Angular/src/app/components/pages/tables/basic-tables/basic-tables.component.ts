import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-tables',
  templateUrl: './basic-tables.component.html',
  styleUrls: ['./basic-tables.component.css']
})
export class BasicTablesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
