import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vector-maps',
  templateUrl: './vector-maps.component.html',
  styleUrls: ['./vector-maps.component.css']
})
export class VectorMapsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
